<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Epaper;
use Illuminate\View\View;

class EpaperController extends Controller
{
    public function __invoke(): View
    {
        $papers = Epaper::where('is_active', 1)
            ->orderByDesc('edition_date')
            ->orderByDesc('id')
            ->get();

        return view('public.epaper', [
            'nav_active' => 'epaper',
            'page_title' => 'ई-पेपर | दैनिक विश्वामित्र',
            'papers' => $papers,
        ]);
    }
}
