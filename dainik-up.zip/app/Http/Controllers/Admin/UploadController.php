<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * CKEditor 5 upload adapter endpoint. Returns the shape CKEditor 5's
 * SimpleUploadAdapter expects: { url: "..." } — or an error payload with 4xx.
 */
class UploadController extends AdminController
{
    use \App\Http\Controllers\Admin\Concerns\HandlesAdminUploads;

    public function image(Request $request): JsonResponse
    {
        // VerifyCsrfToken already gates this route; the adapter sends the token
        // as the standard _token field alongside the file.

        $request->validate([
            'upload' => ['required', 'image', 'mimes:jpg,jpeg,png,gif,webp', 'max:5120'],
        ], [
            'upload.max' => 'चित्र 5MB से बड़ी नहीं होनी चाही। · Image must not exceed 5MB.',
        ], ['upload' => 'चित्र · Image']);

        try {
            $url = $this->storeUpload($request->file('upload'), 'news');
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }

        if (! $url) {
            return response()->json(['error' => 'अपलोड विफल। · Upload failed.'], 422);
        }

        return response()->json([
            'url' => url($url),
        ]);
    }
}
