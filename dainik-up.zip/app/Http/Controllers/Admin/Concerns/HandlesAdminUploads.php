<?php

namespace App\Http\Controllers\Admin\Concerns;

use App\Models\Article;
use App\Models\KeyPoint;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use RuntimeException;

trait HandlesAdminUploads
{
    /**
     * Persist an uploaded file under uploads/<sub>/<Y>/<m> with a random name.
     * @return string|null storage-relative path, or null when nothing was sent
     */
    protected function storeUpload(?UploadedFile $file, string $sub, int $maxBytes = 5 * 1024 * 1024): ?string
    {
        if (! $file || ! $file->isValid()) {
            return null;
        }

        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
        $map = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
            'gif' => 'image/gif', 'webp' => 'image/webp', 'pdf' => 'application/pdf',
        ];

        $ext = strtolower($file->getClientOriginalExtension());
        $mime = $file->getMimeType();

        if (! in_array($ext, $allowed, true) || $map[$ext] !== $mime) {
            throw new RuntimeException('असमर्थित फ़ाइल प्रकार। · Unsupported file type.');
        }

        if ($file->getSize() > $maxBytes) {
            throw new RuntimeException('फ़ाइल बहुत बड़ी है। · File too large.');
        }

        $rel = 'uploads/' . $sub . '/' . date('Y/m') . '/' . date('d') . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
        $abs = public_path($rel);

        if (! is_dir(dirname($abs))) {
            mkdir(dirname($abs), 0755, true);
        }

        $file->move(dirname($abs), basename($abs));

        return $rel;
    }

    /** Delete an uploaded/local file, staying inside uploads/ or assets/. */
    protected function deleteUpload(?string $path): void
    {
        $path = trim((string) $path);
        if ($path === '' || preg_match('#^https?://#i', $path)) {
            return;
        }

        $abs = realpath(public_path($path));
        $uploads = realpath(public_path('uploads'));
        $assets = realpath(public_path('assets'));

        if ($abs && $uploads && str_starts_with($abs, $uploads)) {
            @unlink($abs);

            return;
        }
        if ($abs && $assets && str_starts_with($abs, $assets)) {
            @unlink($abs);
        }
    }

    /**
     * Allowlist sanitizer for rich-text bodies (ported from legacy clean_body()).
     */
    protected function cleanBody(?string $html): string
    {
        $allowed = '<p><br><b><strong><i><em><u><h2><h3><h4><ul><ol><li><blockquote><a><img><figure><figcaption><hr><span><div>';
        $html = strip_tags((string) $html, $allowed);
        $html = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html) ?? '';
        $html = preg_replace('/(href|src)\s*=\s*"\s*javascript:[^"]*"/i', '$1="#"', $html) ?? '';
        $html = preg_replace("/(href|src)\s*=\s*'\s*javascript:[^']*'/i", "$1='#'", $html) ?? '';
        $html = preg_replace('/(href|src)\s*=\s*javascript:[^\s>]+/i', '$1="#"', $html) ?? '';

        return $html;
    }
}
