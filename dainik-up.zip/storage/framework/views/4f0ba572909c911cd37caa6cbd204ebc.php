<!DOCTYPE html>
<html lang="hi">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title><?php echo e($admin_title ?? 'एडमिन'); ?> | दैनिक विश्वामित्र</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700&family=Noto+Serif:wght@600;700&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<style>
body{font-family:'Noto Sans',sans-serif;}
.serif{font-family:'Noto Serif',serif;}
/* Admin sidebar: two-line nav items, one icon/metric grid, no wrapping. */
.nav-item{display:flex;align-items:center;gap:.75rem;padding:.5rem .75rem;border-radius:.5rem;transition:background-color .15s,color .15s;position:relative;}
.nav-item:hover{background:rgba(255,255,255,.06);}
.nav-item.is-active{background:#991b1b;}
.nav-item.is-active .nav-en{opacity:.85;}
.nav-icon{width:20px;height:20px;flex:0 0 20px;display:flex;align-items:center;justify-content:center;font-size:20px;line-height:1;}
.nav-text{min-width:0;display:flex;flex-direction:column;line-height:1.25;}
.nav-hi{font-size:.8125rem;font-weight:600;white-space:nowrap;}
.nav-en{font-size:.6875rem;white-space:nowrap;opacity:.55;}
.nav-group{font-size:.625rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:1rem .75rem .375rem;color:#78716c;}
.admin-scroll{scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.18) transparent;}
.admin-scroll::-webkit-scrollbar{width:6px;}
.admin-scroll::-webkit-scrollbar-track{background:transparent;}
.admin-scroll::-webkit-scrollbar-thumb{background:rgba(255,255,255,.18);border-radius:3px;}
</style>
<style>
/* CKEditor 5 skin overrides to match the admin palette. */
.ck.ck-editor__main>.ck-editor__editable { min-height: 320px; font-size: 15px; line-height: 1.65; color: #1c1917; }
.ck.ck-editor__main>.ck-editor__editable:not(.ck-focused) { border-color: #d6d3d1; }
.ck.ck-toolbar { border-color: #d6d3d1; background: #fafaf9; }
.ck.ck-button:not(.ck-disabled):hover, a.ck.ck-button:not(.ck-disabled):hover { background: #fee2e2; }
.ck.ck-button.ck-on, a.ck.ck-button.ck-on { background: #991b1b; color: #fff; }
.ck.ck-button.ck-on:hover, a.ck.ck-button.ck-on:hover { background: #7f1d1d; color: #fff; }
.ck.ck-dropdown__panel { border-color: #d6d3d1; }
.ck.ck-input:focus, .ck.ck-input-text:focus { border-color: #b91c1c; box-shadow: none; }
.ck.ck-balloon-panel { box-shadow: 0 4px 16px rgba(0,0,0,.14); }
</style>
<?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-stone-100 text-stone-900">

<?php
    $adminUser = session('admin') ?? [];
    // Guest pages (login) get a bare shell: no sidebar, no nav, no user block.
    $isAdminAuthed = $adminUser !== [];
    $adminOnly = in_array(($adminUser['role'] ?? ''), ['admin'], true);

    // Sidebar groups: Hindi label primary, English label underneath.
    $navGroups = [
        [
            'label' => 'सामग्री', 'en' => 'Content',
            'items' => [
                ['admin.dashboard', 'dashboard', 'डैशबोर्ड', 'Dashboard'],
                ['admin.articles', 'article', 'समाचार', 'Articles'],
                ['admin.categories', 'category', 'श्रेणियाँ', 'Categories'],
                ['admin.pages', 'description', 'पेज', 'Pages'],
            ],
        ],
        [
            'label' => 'मॉड्यूल', 'en' => 'Modules',
            'items' => [
                ['admin.ticker', 'campaign', 'टिकर', 'Ticker'],
                ['admin.bulletins', 'bolt', 'बुलेटिन', 'Bulletins'],
                ['admin.market', 'trending_up', 'बाज़ार', 'Market'],
                ['admin.videos', 'videocam', 'वीडियो', 'Videos'],
                ['admin.horoscope', 'stars', 'राशिफल', 'Horoscope'],
                ['admin.polls', 'ballot', 'जनमत', 'Polls'],
                ['admin.elections', 'event', 'चुनाव कैलेंडर', 'Elections'],
            ],
        ],
        [
            'label' => 'प्रकाशन', 'en' => 'Publishing',
            'items' => [
                ['admin.epapers', 'menu_book', 'ई-पेपर', 'Epaper'],
                ['admin.messages', 'inbox', 'संदेश', 'Messages'],
                ['admin.subscribers', 'mail', 'न्यूज़लेटर', 'Subscribers'],
            ],
        ],
    ];

    $adminGroup = [
        'label' => 'प्रशासन', 'en' => 'Administration',
        'items' => [
            ['admin.users', 'group', 'उपयोगकर्ता', 'Users'],
            ['admin.settings', 'settings', 'सेटिंग्स', 'Settings'],
        ],
    ];
    if ($adminOnly) {
        $navGroups[] = $adminGroup;
    }
?>

<?php if($isAdminAuthed): ?>
<div class="flex min-h-screen">
<aside class="w-64 shrink-0 bg-[#1c1917] text-stone-200 hidden md:flex flex-col border-r border-black/40">
<div class="px-4 py-4 border-b border-white/10 flex items-center gap-3">
<span class="material-symbols-outlined text-[28px] text-red-500">newsmode</span>
<div class="min-w-0">
<div class="serif font-bold text-base text-white leading-tight truncate">दैनिक विश्वामित्र</div>
<div class="text-[11px] text-stone-400 leading-tight">एडमिन पैनल · Admin</div>
</div>
</div>
<nav class="flex-1 overflow-y-auto admin-scroll py-2 px-2">
<?php $__currentLoopData = $navGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="nav-group"><?php echo e($group['label']); ?> · <?php echo e($group['en']); ?></div>
<?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $icon, $hi, $en]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($active = request()->routeIs($route) || request()->routeIs($route.'.*')); ?>
    <a href="<?php echo e(route($route)); ?>" class="nav-item <?php echo e($active ? 'is-active text-white' : 'text-stone-300'); ?>" <?php if($active): ?> aria-current="page" <?php endif; ?>>
        <span class="nav-icon material-symbols-outlined"><?php echo e($icon); ?></span>
        <span class="nav-text"><span class="nav-hi"><?php echo e($hi); ?></span><span class="nav-en"><?php echo e($en); ?></span></span>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<div class="p-3 border-t border-white/10">
<div class="flex items-center gap-3 px-1 py-1.5">
<div class="w-9 h-9 rounded-full bg-red-800 text-white flex items-center justify-center font-bold text-sm shrink-0"><?php echo e(mb_substr((string) ($adminUser['name'] ?? 'A'), 0, 1)); ?></div>
<div class="min-w-0 flex-1">
<div class="text-sm font-semibold text-white truncate"><?php echo e(e($adminUser['name'] ?? '')); ?></div>
<div class="text-[11px] text-stone-400 truncate"><?php echo e(e($adminUser['role'] ?? '')); ?></div>
</div>
</div>
<div class="grid grid-cols-2 gap-2 mt-2">
<a class="text-center text-xs px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 text-stone-300 transition-colors" target="_blank" href="<?php echo e(url('/')); ?>">साइट देखें · View site</a>
<a class="text-center text-xs px-2 py-1.5 rounded bg-red-900/60 hover:bg-red-900 text-red-200 transition-colors" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();">लॉगआउट · Log out</a>
<form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="post" class="hidden"><?php echo csrf_field(); ?></form>
</div>
</div>
</aside>
<div class="flex-1 min-w-0 flex flex-col">
<?php endif; ?>


<?php if($isAdminAuthed): ?>
<div class="md:hidden sticky top-0 z-30 bg-[#1c1917] text-white px-4 py-3 flex items-center justify-between">
<span class="serif font-bold flex items-center gap-2"><span class="material-symbols-outlined text-red-500">newsmode</span>दैनिक विश्वामित्र · एडमिन</span>
<button type="button" onclick="document.getElementById('mob-nav').classList.toggle('hidden')" class="p-1.5 rounded hover:bg-white/10 transition-colors" aria-label="मेनू · Menu"><span class="material-symbols-outlined">menu</span></button>
</div>
<div id="mob-nav" class="md:hidden hidden bg-[#1c1917] text-stone-200 px-3 pb-3 border-b border-white/10">
<?php $__currentLoopData = $navGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="nav-group"><?php echo e($group['label']); ?> · <?php echo e($group['en']); ?></div>
<?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $icon, $hi, $en]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($active = request()->routeIs($route) || request()->routeIs($route.'.*')); ?>
    <a href="<?php echo e(route($route)); ?>" class="nav-item <?php echo e($active ? 'is-active text-white' : 'text-stone-300'); ?>">
        <span class="nav-icon material-symbols-outlined"><?php echo e($icon); ?></span>
        <span class="nav-text"><span class="nav-hi"><?php echo e($hi); ?></span><span class="nav-en"><?php echo e($en); ?></span></span>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('admin.logout')); ?>" method="post" class="mt-2"><?php echo csrf_field(); ?><button class="w-full text-center text-xs px-2 py-2 rounded bg-red-900/60 text-red-200" type="submit">लॉगआउट · Log out</button></form>
</div>
<?php else: ?>
<div class="md:hidden bg-[#1c1917] text-white px-4 py-3 flex items-center justify-center">
<span class="serif font-bold flex items-center gap-2"><span class="material-symbols-outlined text-red-500">newsmode</span>दैनिक विश्वामित्र · एडमिन</span>
</div>
<?php endif; ?>

<?php if($isAdminAuthed): ?>
<main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-6xl mx-auto">
<div class="mb-6">
<h1 class="serif text-2xl font-bold text-stone-900 leading-tight"><?php echo e(e($admin_title ?? '')); ?></h1>
</div>
<?php else: ?>
<main class="min-h-[calc(100vh-3.5rem)] flex items-center justify-center p-4 sm:p-6 max-w-6xl mx-auto">
<?php endif; ?>

<?php if(session('ok')): ?>
<div class="mb-3 px-4 py-2.5 rounded-lg text-sm font-medium bg-green-100 text-green-800 border border-green-200"><?php echo e(session('ok')); ?></div>
<?php endif; ?>
<?php if(session('err')): ?>
<div class="mb-3 px-4 py-2.5 rounded-lg text-sm font-medium bg-red-100 text-red-800 border border-red-200"><?php echo e(session('err')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="mb-3 px-4 py-2.5 rounded-lg text-sm font-medium bg-red-100 text-red-800 border border-red-200">
<ul class="list-disc list-inside space-y-0.5">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</main>

<?php if($isAdminAuthed): ?>
<footer class="px-6 py-4 text-xs text-stone-500 border-t border-stone-200 w-full max-w-6xl mx-auto">दैनिक विश्वामित्र · एडमिन पैनल v<?php echo e(config('app.version', '1.0.0')); ?></footer>
</div>
</div>
<?php endif; ?>


<script src="https://cdn.jsdelivr.net/npm/@ckeditor/ckeditor5-build-classic@42.0.2/build/ckeditor.js"></script>
<script>
(function () {
    var editorEl = document.getElementById('body');
    if (!editorEl) return;

    function initEditor() {
        if (typeof ClassicEditor === 'undefined') return;

    class VishwamitraUploadAdapter {
        constructor(loader) { this.loader = loader; }
        upload() {
            return this.loader.file.then(function (file) {
                if (file.size > 5 * 1024 * 1024) {
                    return Promise.reject('चित्र 5MB से बड़ी नहीं होनी चाही। · Image must not exceed 5MB.');
                }
                return new Promise(function (resolve, reject) {
                    var data = new FormData();
                    data.append('upload', file);
                    data.append('csrf', '<?php echo e(csrf_token()); ?>');
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?php echo e(url('admin/upload/image')); ?>', true);
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.onload = function () {
                        if (xhr.status < 200 || xhr.status >= 300) {
                            var msg = 'अपलोड विफल। · Upload failed.';
                            try { msg = JSON.parse(xhr.responseText).error || msg; } catch (e) {}
                            return reject(msg);
                        }
                        var res = JSON.parse(xhr.responseText);
                        resolve({ default: res.url });
                    };
                    xhr.onerror = function () { reject('नेटवर्क त्रुटि — अपलोड विफल। · Network error — upload failed.'); };
                    xhr.send(data);
                });
            });
        }
        abort() {}
    }

    function VishwamitraAdapterPlugin(editor) {
        editor.plugins.get('FileRepository').createUploadAdapter = function (loader) {
            return new VishwamitraUploadAdapter(loader);
        };
    }

    ClassicEditor.create(editorEl, {
        language: 'hi',
        extraPlugins: [VishwamitraAdapterPlugin],
        toolbar: {
            shouldNotGroupWhenFull: true,
            items: ['undo', 'redo', '|', 'heading', '|', 'bold', 'italic', 'underline', 'strikethrough',
                    '|', 'link', 'uploadImage', 'insertTable', 'blockQuote', 'mediaEmbed', 'horizontalLine',
                    '|', 'bulletedList', 'numberedList', 'outdent', 'indent', '|',
                    'alignment', 'removeFormat', 'sourceEditing']
        },
        heading: { options: [
            { model: 'paragraph', title: 'पैराग्राफ़', view: 'p' },
            { model: 'heading2', view: 'h2', title: 'शीर्षक 2' },
            { model: 'heading3', view: 'h3', title: 'शीर्षक 3' },
            { model: 'heading4', view: 'h4', title: 'शीर्षक 4' }
        ]},
        image: { toolbar: ['imageStyle:inline', 'imageStyle:wrapText', 'imageStyle:side', '|', 'toggleImageCaption', 'imageTextAlternative'] },
        table: { contentToolbar: ['tableColumn', 'tableRow', 'mergeTableCells'] },
        language: 'hi'
    }).then(function (editor) {
        window.activeEditor = editor;
    }).catch(function () {
        // No CKEditor (offline): the textarea still works as a normal field.
    });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initEditor);
    } else {
        initEditor();
    }
})();
</script>
<script>
document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    var bad = [];
    form.querySelectorAll('input[type=file][data-max-kb]').forEach(function (inp) {
        if (inp.files && inp.files[0] && inp.files[0].size > parseInt(inp.getAttribute('data-max-kb'), 10) * 1024) {
            bad.push(inp.getAttribute('data-label') || inp.name);
        }
    });
    if (bad.length) {
        e.preventDefault();
        alert('चयनित फ़ाइल बहुत बड़ी है: ' + bad.join(', ') + ' — कृपया छोटी फ़ाइल चुनें।\nSelected file(s) too large: ' + bad.join(', ') + ' — please choose smaller files.');
    }
});
</script>

</body>
</html>
<?php /**PATH /home/adam/Downloads/stitch_dainik_vishwamitra_news_redesign/laravel-app/resources/views/layouts/admin.blade.php ENDPATH**/ ?>