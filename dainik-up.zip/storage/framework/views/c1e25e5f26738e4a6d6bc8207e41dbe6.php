<?php $__env->startSection('content'); ?>
<?php ($errMsg = $err ?? ($msg ?? null)); ?>
<div class="w-full max-w-sm bg-white rounded-xl shadow-sm border border-stone-200 p-8">
<div class="text-center mb-6">
<div class="font-bold text-2xl text-red-800 serif">दैनिक विश्वामित्र</div>
<div class="text-sm text-stone-500 mt-1">एडमिन पैनल — कृपया लॉगिन करें · Admin panel — please log in</div>
</div>
<?php if($errMsg): ?><div class="mb-4 px-3 py-2 rounded text-sm bg-red-100 text-red-800"><?php echo e($errMsg); ?></div><?php endif; ?>
<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mb-4 px-3 py-2 rounded text-sm bg-red-100 text-red-800"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mb-4 px-3 py-2 rounded text-sm bg-red-100 text-red-800"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<form method="post" action="<?php echo e(route('admin.login.attempt')); ?>" class="space-y-4">
<?php echo csrf_field(); ?>
<div>
<label class="block text-sm font-semibold mb-1 text-stone-700">उपयोगकर्ता नाम / Username</label>
<input name="username" required autofocus value="<?php echo e(old('username')); ?>" class="w-full px-3 py-2 border border-stone-300 rounded focus:outline-none focus:border-red-800 focus:ring-1 focus:ring-red-800/20"/>
</div>
<div>
<label class="block text-sm font-semibold mb-1 text-stone-700">पासवर्ड / Password</label>
<input name="password" required type="password" class="w-full px-3 py-2 border border-stone-300 rounded focus:outline-none focus:border-red-800 focus:ring-1 focus:ring-red-800/20"/>
</div>
<button class="w-full bg-red-800 hover:bg-red-900 text-white py-2.5 rounded font-semibold transition-colors" type="submit">लॉगिन करें · Log in</button>
</form>
<p class="mt-4 text-xs text-stone-500 text-center">अनधिकृत प्रवेश वर्जित है। · Unauthorized access is prohibited.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/adam/Downloads/stitch_dainik_vishwamitra_news_redesign/laravel-app/resources/views/admin/login.blade.php ENDPATH**/ ?>