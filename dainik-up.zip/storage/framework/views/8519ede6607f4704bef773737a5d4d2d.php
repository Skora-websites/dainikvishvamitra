<?php $__env->startSection('content'); ?>
<?php
$stats = $stats ?? [];
$cards = [
    ['समाचार (प्रकाशित)', 'Published articles', $stats['published'] ?? 0, 'article', 'admin.articles', null],
    ['ड्राफ़्ट', 'Drafts', $stats['drafts'] ?? 0, 'edit_note', 'admin.articles', ['status' => 'draft']],
    ['श्रेणियाँ', 'Categories', $stats['categories'] ?? 0, 'category', 'admin.categories', null],
    ['न्यूज़लेटर पाठक', 'Subscribers', $stats['subs'] ?? 0, 'mail', 'admin.subscribers', null],
    ['कुल पाठक (व्यूज़)', 'Total views', $stats['views'] ?? 0, 'visibility', 'admin.articles', null],
    ['अपठित संदेश', 'Unread messages', $stats['unread'] ?? 0, 'inbox', 'admin.messages', null],
];
?>
<div class="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
<?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$hi, $en, $n, $icon, $route, $params]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route($route, $params ?? [])); ?>" class="bg-white rounded-lg border p-4 hover:shadow transition-shadow">
<div class="flex items-center gap-2 text-stone-500 text-xs"><span class="material-symbols-outlined text-[20px]"><?php echo e($icon); ?></span><?php echo e($hi); ?> · <?php echo e($en); ?></div>
<div class="text-3xl font-bold mt-1"><?php echo e(\App\Support\Site::hiDigits(number_format((int) $n))); ?></div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="bg-white rounded-lg border">
<div class="flex items-center justify-between mb-3 px-4 pt-4">
<h2 class="font-bold">ताज़ा समाचार · Latest articles</h2>
<a href="<?php echo e(route('admin.articles.create')); ?>" class="text-sm bg-red-800 hover:bg-red-900 text-white px-3 py-1.5 rounded font-semibold">+ नया समाचार · New</a>
</div>
<div class="divide-y text-sm">
<?php $__currentLoopData = ($recent ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="px-4 py-2.5 flex items-center justify-between gap-3">
<div class="min-w-0">
<span class="text-xs text-stone-500"><?php echo e($l->category->name_hi ?? ''); ?> · <?php echo e(\App\Support\Site::timeAgo($l->published_at)); ?></span>
<div class="truncate font-medium"><?php echo e($l->title); ?></div>
</div>
<div class="flex items-center gap-2 shrink-0">
<span class="text-xs px-2 py-0.5 rounded <?php echo e($l->status === 'published' ? 'bg-green-100 text-green-800' : 'bg-stone-200 text-stone-600'); ?>"><?php echo e($l->status === 'published' ? 'प्रकाशित · Published' : 'ड्राफ़्ट · Draft'); ?></span>
<a class="text-red-800 hover:underline text-xs" href="<?php echo e(route('admin.articles.edit', $l->id)); ?>">संपादित करें · Edit</a>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(($recent ?? collect())->isEmpty()): ?><div class="px-4 py-6 text-center text-stone-500">कोई समाचार नहीं। · No articles.</div><?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/adam/Downloads/stitch_dainik_vishwamitra_news_redesign/laravel-app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>