@php
use App\Models\Page;

// Legacy clean_body(): allowlist tags, strip event handlers + javascript: URLs.
$clean_body = static function (string $html): string {
    $allowed = '<p><br><b><strong><i><em><u><h2><h3><h4><ul><ol><li><blockquote><a><img><figure><figcaption><hr><span><div>';
    $html = strip_tags($html, $allowed);
    $html = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
    $html = preg_replace('/(href|src)\s*=\s*"\s*javascript:[^"]*"/i', '$1="#"', $html);
    $html = preg_replace("/(href|src)\s*=\s*'\s*javascript:[^']*'/i", "$1='#'", $html);
    $html = preg_replace('/(href|src)\s*=\s*javascript:[^\s>]+/i', '$1="#"', $html);

    return (string) $html;
};

// Legacy page.php: ?slug=, published only; else the shared 404 state.
$slug = trim((string) request('slug', ''));
$pg = $slug !== '' ? Page::where('slug', $slug)->where('status', 'published')->first() : null;

$active_nav = '';
$page_title = ($pg->title ?? 'पृष्ठ') . ' | दैनिक विश्वामित्र';
$page_desc = 'दैनिक विश्वामित्र';

$__sb = App\Http\View\Composers\PublicLayoutComposer::sidebarData(null);
extract($__sb);
$is_politics = ($is_politics ?? false);
$archive = ($archive ?? null);
$sidebar_back = $pg ? url('page/' . $pg->slug) : '';
@endphp

@extends('layouts.public')

@section('content')
@if (!$pg)
    @include('public.404', [
        'not_found_title' => 'पृष्ठ नहीं मिला',
        'not_found_msg' => 'यह पृष्ठ उपलब्ध नहीं है या हटा दिया गया है।',
    ])
@else
<main class="w-full pt-44 bg-surface"><div class="max-w-7xl mx-auto px-4 lg:px-8 py-6">
<div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
<div class="lg:col-span-8">
<article class="bg-surface-container-lowest rounded-lg shadow-sm p-6 sm:p-8">
<div class="flex items-center gap-3 mb-4">
<span class="w-1.5 h-6 bg-primary rounded"></span>
<h1 class="font-headline-lg text-headline-lg text-ink-primary">{{ e($pg->title) }}</h1>
</div>
<div class="font-body-lg text-body-lg text-ink-secondary leading-relaxed space-y-4 article-body">
{!! $clean_body((string) $pg->body) !!}
</div>
</article>
</div>
@include('partials.sidebar')</div>
</div></main>
<style>.article-body p{margin-bottom:1rem}.article-body a{color:#9b000e;text-decoration:underline}</style>
@endif
@endsection
