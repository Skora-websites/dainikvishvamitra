@php
use App\Models\Epaper;

// Legacy epaper.php: newest editions first, LIMIT 12.
$papers = Epaper::where('is_active', 1)
    ->orderByDesc('edition_date')
    ->orderByDesc('id')
    ->limit(12)
    ->get();

$is_politics = false;
$active_nav = '';
$page_title = 'ई-पेपर | दैनिक विश्वामित्र';
$page_desc = 'दैनिक विश्वामित्र का प्रिंट संस्करण PDF रूप में पढ़ें व डाउनलोड करें।';

$__sb = App\Http\View\Composers\PublicLayoutComposer::sidebarData(null);
extract($__sb);
$archive = ($archive ?? null);
$sidebar_back = '';
@endphp

@extends('layouts.public')

@section('content')
<main class="w-full pt-44 bg-surface"><div class="max-w-7xl mx-auto px-4 lg:px-8 py-6">
<div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
<div class="lg:col-span-8 flex flex-col gap-4">
<div class="bg-surface-container-lowest rounded-lg shadow-sm p-6">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-primary text-[24px]">menu_book</span>
<div>
<h1 class="font-headline-md text-headline-md text-ink-primary">ई-पेपर आर्काइव (E-Paper PDF)</h1>
<p class="font-caption text-caption text-ink-secondary">दैनिक विश्वामित्र का प्रिंट संस्करण PDF रूप में पढ़ें व डाउनलोड करें।</p>
</div>
</div>
</div>
@if ($papers->isNotEmpty())
<div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
@foreach ($papers as $p)
<div class="bg-surface-container-lowest p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex gap-4 items-center">
<div class="w-20 h-24 rounded overflow-hidden shrink-0 bg-surface-container flex items-center justify-center">
@if (!empty($p->cover_image))<img class="w-full h-full object-cover" alt="{{ e($p->title) }}" src="{{ asset(ltrim((string) $p->cover_image, '/')) }}"/>@else<span class="material-symbols-outlined text-ink-muted text-[32px]">newspaper</span>@endif
</div>
<div class="min-w-0 flex-1">
<h3 class="font-headline-sm text-headline-sm text-ink-primary leading-snug">{{ e($p->title) }}</h3>
<p class="font-caption text-caption text-ink-muted mt-1">{{ e(\App\Support\Site::hiDateShort($p->edition_date)) }}</p>
<a href="{{ asset(ltrim((string) $p->pdf_path, '/')) }}" target="_blank" rel="noopener" class="inline-flex items-center gap-1.5 mt-2 bg-primary text-on-primary px-3 py-1.5 rounded text-xs font-semibold hover:bg-masthead-crimson transition-colors"><span class="material-symbols-outlined text-[16px]">picture_as_pdf</span> PDF पढ़ें / डाउनलोड करें</a>
</div>
</div>
@endforeach
</div>
@else
<div class="bg-surface-container-lowest p-10 rounded-lg text-center">
<span class="material-symbols-outlined text-ink-muted text-[48px]">menu_book</span>
<p class="font-body-md text-body-md text-ink-secondary mt-3">ई-पेपर अंक शीघ्र उपलब्ध होंगे। कृपया पुनः पधारें।</p>
</div>
@endif
</div>
@include('partials.sidebar')</div>
</div></main>
@endsection
