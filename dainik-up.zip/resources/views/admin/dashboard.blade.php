@extends('layouts.admin')

@section('content')
@php
$stats = $stats ?? [];
$cards = [
    ['समाचार (प्रकाशित)', 'Published articles', $stats['published'] ?? 0, 'article', 'admin.articles', null],
    ['ड्राफ़्ट', 'Drafts', $stats['drafts'] ?? 0, 'edit_note', 'admin.articles', ['status' => 'draft']],
    ['श्रेणियाँ', 'Categories', $stats['categories'] ?? 0, 'category', 'admin.categories', null],
    ['न्यूज़लेटर पाठक', 'Subscribers', $stats['subs'] ?? 0, 'mail', 'admin.subscribers', null],
    ['कुल पाठक (व्यूज़)', 'Total views', $stats['views'] ?? 0, 'visibility', 'admin.articles', null],
    ['अपठित संदेश', 'Unread messages', $stats['unread'] ?? 0, 'inbox', 'admin.messages', null],
];
@endphp
<div class="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
@foreach($cards as [$hi, $en, $n, $icon, $route, $params])
<a href="{{ route($route, $params ?? []) }}" class="bg-white rounded-lg border p-4 hover:shadow transition-shadow">
<div class="flex items-center gap-2 text-stone-500 text-xs"><span class="material-symbols-outlined text-[20px]">{{ $icon }}</span>{{ $hi }} · {{ $en }}</div>
<div class="text-3xl font-bold mt-1">{{ \App\Support\Site::hiDigits(number_format((int) $n)) }}</div>
</a>
@endforeach
</div>
<div class="bg-white rounded-lg border">
<div class="flex items-center justify-between mb-3 px-4 pt-4">
<h2 class="font-bold">ताज़ा समाचार · Latest articles</h2>
<a href="{{ route('admin.articles.create') }}" class="text-sm bg-red-800 hover:bg-red-900 text-white px-3 py-1.5 rounded font-semibold">+ नया समाचार · New</a>
</div>
<div class="divide-y text-sm">
@foreach(($recent ?? collect()) as $l)
<div class="px-4 py-2.5 flex items-center justify-between gap-3">
<div class="min-w-0">
<span class="text-xs text-stone-500">{{ $l->category->name_hi ?? '' }} · {{ \App\Support\Site::timeAgo($l->published_at) }}</span>
<div class="truncate font-medium">{{ $l->title }}</div>
</div>
<div class="flex items-center gap-2 shrink-0">
<span class="text-xs px-2 py-0.5 rounded {{ $l->status === 'published' ? 'bg-green-100 text-green-800' : 'bg-stone-200 text-stone-600' }}">{{ $l->status === 'published' ? 'प्रकाशित · Published' : 'ड्राफ़्ट · Draft' }}</span>
<a class="text-red-800 hover:underline text-xs" href="{{ route('admin.articles.edit', $l->id) }}">संपादित करें · Edit</a>
</div>
</div>
@endforeach
@if(($recent ?? collect())->isEmpty())<div class="px-4 py-6 text-center text-stone-500">कोई समाचार नहीं। · No articles.</div>@endif
</div>
</div>
@endsection
