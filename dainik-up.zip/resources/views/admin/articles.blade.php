@extends('layouts.admin')

@section('content')
<div class="bg-white rounded-lg border p-4 mb-4">
<form method="GET" action="{{ route('admin.articles') }}" class="flex flex-wrap gap-2 items-end">
<div>
<label class="block text-xs font-semibold mb-1">खोजें · Search</label>
<input name="q" value="{{ e($q ?? '') }}" class="px-3 py-1.5 border rounded focus:outline-none focus:border-red-800 text-sm w-56" placeholder="शीर्षक / लेखक · Title / author"/>
</div>
<div>
<label class="block text-xs font-semibold mb-1">स्थिति · Status</label>
<select name="status" class="px-3 py-1.5 border rounded focus:outline-none focus:border-red-800 text-sm">
<option value="">सभी · All</option>
<option value="published" {{ ($status ?? '') === 'published' ? 'selected' : '' }}>प्रकाशित · Published</option>
<option value="draft" {{ ($status ?? '') === 'draft' ? 'selected' : '' }}>ड्राफ़्ट · Draft</option>
</select>
</div>
<div>
<label class="block text-xs font-semibold mb-1">श्रेणी · Category</label>
<select name="cat" class="px-3 py-1.5 border rounded focus:outline-none focus:border-red-800 text-sm">
<option value="0">सभी · All</option>
@php($catFilter = (int) request('cat', 0))
@foreach(($cats ?? []) as $c)<option value="{{ (int) $c->id }}" {{ $catFilter === (int) $c->id ? 'selected' : '' }}>{{ $c->name_hi }}</option>@endforeach
</select>
</div>
<button class="bg-stone-800 text-white px-4 py-1.5 rounded text-sm">लागू करें · Apply</button>
<a href="{{ route('admin.articles.create') }}" class="bg-red-800 hover:bg-red-900 text-white px-4 py-1.5 rounded text-sm font-semibold">+ नया समाचार · New</a>
</form>
</div>
<div class="bg-white rounded-lg border overflow-x-auto">
<table class="w-full text-sm min-w-[760px]">
<thead><tr class="text-left text-xs text-stone-500 border-b">
<th class="px-4 py-2">शीर्षक · Title</th><th class="px-4 py-2">श्रेणी · Category</th><th class="px-4 py-2">स्थिति · Status</th><th class="px-4 py-2">व्यूज़ · Views</th><th class="px-4 py-2">अपडेट · Updated</th><th class="px-4 py-2">कार्य · Actions</th>
</tr></thead>
<tbody class="divide-y">
@foreach(($articles ?? []) as $r)
<tr>
<td class="px-4 py-2"><div class="font-medium">{{ $r->title }}</div><div class="text-xs text-stone-500">{{ $r->slug }}@if(!empty($r->home_slot) || !empty($r->cat_slot)) · <span class="text-red-700 font-semibold">[{{ trim(($r->home_slot ?? '') . ' ' . ($r->cat_slot ?? '')) }}]</span>@endif</div></td>
<td class="px-4 py-2 text-xs">{{ $r->category->name_hi ?? '' }}</td>
<td class="px-4 py-2"><span class="text-xs px-2 py-0.5 rounded {{ $r->status === 'published' ? 'bg-green-100 text-green-800' : 'bg-stone-200 text-stone-600' }}">{{ $r->status === 'published' ? 'प्रकाशित · Published' : 'ड्राफ़्ट · Draft' }}</span></td>
<td class="px-4 py-2">{{ \App\Support\Site::hiDigits(number_format((int) $r->views)) }}</td>
<td class="px-4 py-2 text-xs text-stone-500">{{ \App\Support\Site::timeAgo($r->updated_at) }}</td>
<td class="px-4 py-2 whitespace-nowrap">
<a class="text-red-800 hover:underline text-xs mr-2" href="{{ route('admin.articles.edit', $r->id) }}">संपादित करें · Edit</a>
<a class="text-stone-500 hover:underline text-xs mr-2" target="_blank" href="{{ url('article/' . $r->slug) }}">देखें · View</a>
<form method="post" action="{{ route('admin.articles.delete', $r->id) }}" class="inline" onsubmit="return confirm('हटाएं? / Delete?')">@csrf<button class="text-red-600 hover:underline text-xs" type="submit">हटाएं · Delete</button></form>
</td>
</tr>
@endforeach
@if(($articles ?? collect())->isEmpty())<tr><td colspan="6" class="px-4 py-6 text-center text-stone-500">कोई समाचार नहीं मिला। · No articles found.</td></tr>@endif
</tbody>
</table>
</div>
@if(method_exists($articles ?? null, 'links'))
<div class="mt-3">{{ $articles->links() }}</div>
@endif
@endsection
